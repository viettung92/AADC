Dieser Ordner enthält die Sourcen der vorkompilierten Basismodule zur Ansteuerung des AADC-Fahrzeugs. Änderungen sind lokal möglich, werden aber zum Wettbewerb auf einen einheitlichen Stand gebracht. Siehe hierzu auch die Wettbewerbsregeln.

Folders:
* AADC_ADTF_BaseFilters:	Hier liegen alle Basisfilter die zum Auslesen der Sensoren und zur Steuerung der Aktuatoren benötigt werden. Außerdem finden sich hier Filter für Visualisierung der Daten und Umrechnung der Signalwerte.

Files:
* CMakeLists.txt:		 Dies ist die Start-CMake-Datei zum Bauen der Basissystem-Filter
* Readme_before_change_anything.txt: Diese Datei